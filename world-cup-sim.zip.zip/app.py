import streamlit as st

from simulator import run_simulations
from groups_data import groups

st.set_page_config(
    page_title="FIFA 2026 World Cup Simulator",
    page_icon="⚽",
    layout="wide",
)

st.title("⚽ FIFA 2026 World Cup Simulator")

st.markdown(
    """
Monte Carlo simulation of the **2026 FIFA World Cup**.

Adjust the simulation settings in the sidebar and click **Run Simulation**.
"""
)

# -------------------------
# Sidebar
# -------------------------

st.sidebar.header("Simulation")

n_sims = st.sidebar.number_input(
    "Number of simulations",
    min_value=1,
    max_value=100000,
    value=10000,
    step=1000,
)

run = st.sidebar.button(
    "▶ Run Simulation",
    use_container_width=True,
)

# -------------------------
# Run simulation
# -------------------------

if run:

    with st.spinner("Running simulations..."):

        results, runtime = run_simulations(
            groups,
            n_sims,
        )

    st.success(
        f"Completed {n_sims:,} simulations in {runtime:.2f} seconds."
    )

    # -------------------------
    # Top contenders
    # -------------------------

    st.subheader("🏆 Top Championship Contenders")

    contenders = (
        results
        .sort_values(
            "champion_pct",
            ascending=False,
        )
        .head(10)
    )

    for _, row in contenders.iterrows():

        st.progress(
            row["champion_pct"] / 100,
            text=f'{row["team"]} — {row["champion_pct"]:.2f}%'
        )

    st.divider()

    # -------------------------
    # Chart
    # -------------------------

    left, right = st.columns([2, 1])

    with left:

        st.subheader("Championship Probability")

        chart = (
            results
            .sort_values(
                "champion_pct",
                ascending=False,
            )
            .set_index("team")
        )

        st.bar_chart(
            chart["champion_pct"]
        )

    with right:

        st.subheader("Runtime")

        st.metric(
            "Simulation time",
            f"{runtime:.2f}s"
        )

        st.metric(
            "Simulations",
            f"{n_sims:,}"
        )

        st.metric(
            "Teams",
            len(results)
        )

    st.divider()

    # -------------------------
    # Table
    # -------------------------

    st.subheader("Team Statistics")

    display = (
        results[
            [
                "team",
                "group",
                "pot",
                "champion_pct",
                "fantasy_score",
                "avg_gf",
                "avg_ga",
            ]
        ]
        .rename(
            columns={
                "team": "Team",
                "group": "Group",
                "pot": "Pot",
                "champion_pct": "Champion %",
                "fantasy_score": "Fantasy Score",
                "avg_gf": "Avg GF",
                "avg_ga": "Avg GA",
            }
        )
    )

    st.dataframe(
        display,
        use_container_width=True,
        hide_index=True,
    )

    st.download_button(
        label="📥 Download CSV",
        data=display.to_csv(index=False),
        file_name="world_cup_simulation.csv",
        mime="text/csv",
    )